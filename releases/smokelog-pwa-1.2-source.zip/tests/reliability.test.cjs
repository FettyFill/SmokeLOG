const { test } = require('node:test');
const assert = require('node:assert/strict');
const { harness } = require('./harness.cjs');
const { calculate } = require('../insights.js');
test('HTTP preserves missing-RPC errors through the real request layer', async () => {
  const run = harness();
  const result = await run(`(async () => {
    supabaseConfig.url = 'https://example.supabase.co';
    fetch = async url => ({ ok: !url.includes('/rpc/'), status: url.includes('/rpc/') ? 404 : 200,
      text: async () => url.includes('/rpc/') ? JSON.stringify({code:'PGRST202',message:'missing'}) : '[]' });
    return originalFetchCloudSnapshot('account');
  })()`);
  assert.equal(result.events.length, 0);
  await assert.rejects(run(`(async () => { fetch = async () => ({ok:false,status:403,text:async()=>JSON.stringify({code:'42501',message:'forbidden'})}); return originalFetchCloudSnapshot('account'); })()`), /forbidden/);
});
test('pending edit survives remote clock ahead and keeps its base revision', () => {
  const run = harness();
  const result = run(`mergePendingRecords([{id:'one',type:'cigarette',timestamp:'2026-01-01',updatedAt:'2026-01-01',revision:'7',pendingSync:true}], [{id:'one',type:'joint',timestamp:'2026-01-01',updatedAt:'2099-01-01',revision:'8'}])`);
  assert.equal(result[0].type, 'cigarette'); assert.equal(result[0].revision, '7');
});
test('unknown days suppress comparisons and confirmed zero days count toward coverage', () => {
  const now = new Date(2026,9,30,12);
  const data = calculate([], [], now, 'all', {confirmedDays:{'2026-10-29':true}});
  assert.equal(data.coveredDays,1); assert.equal(data.dailySpend,0); assert.equal(data.comparable,false); assert.equal(data.countChange,null);
});
test('uniform hourly observations have no dominant period', () => {
  const data = calculate([1,7,13,19].map(hour=>({timestamp:new Date(2026,9,29,hour).toISOString()})),[],new Date(2026,9,30));
  assert.deepEqual(data.peakTimes,[]);
});
test('v4 backup rejects malformed detail before writing', () => {
  const run = harness();
  assert.throws(()=>run(`validateRecordDetails({quantity:-1,unit:'g'})`),/Quantità/);
  assert.throws(()=>run(`validateRecordDetails({quantity:1,unit:'inventata'})`),/Unità/);
});
